package com.fincatto.documentofiscal.cte300;

/**
 * @deprecated Utilizar a classe {@link com.fincatto.documentofiscal.cte.CTeConfig}
 */
@Deprecated
public abstract class CTeConfig extends com.fincatto.documentofiscal.cte.CTeConfig {
    // mantida essa classe apenas como subclasse da CTeConfig genérica para manter compatibilidade com versões anteriores
}

package com.fincatto.documentofiscal.cte300.classes;

import org.junit.Assert;
import org.junit.Test;

import com.fincatto.documentofiscal.cte300.classes.CTClasseTarifa;


public class CTClasseTarifaTest {

    @Test
    public void deveRepresentarOCodigoCorretamente() {
    	Assert.assertNull(CTClasseTarifa.valueOfCodigo(null));
        Assert.assertEquals("M", CTClasseTarifa.MINIMA.getCodigo());
        Assert.assertEquals("G", CTClasseTarifa.GERAL.getCodigo());
        Assert.assertEquals("E", CTClasseTarifa.ESPECIFICA.getCodigo());
    }

}

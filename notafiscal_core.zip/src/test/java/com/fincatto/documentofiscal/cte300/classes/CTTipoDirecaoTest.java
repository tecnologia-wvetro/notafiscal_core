package com.fincatto.documentofiscal.cte300.classes;

import org.junit.Assert;
import org.junit.Test;

import com.fincatto.documentofiscal.cte300.classes.CTTipoDirecao;

public class CTTipoDirecaoTest {

    @Test
    public void deveRepresentarOCodigoCorretamente() {
    	Assert.assertNull(CTTipoDirecao.valueOfCodigo(null));
    	Assert.assertEquals("N", CTTipoDirecao.NORTE.getCodigo());
    	Assert.assertEquals("L", CTTipoDirecao.LESTE.getCodigo());
    	Assert.assertEquals("S", CTTipoDirecao.SUL.getCodigo());
    	Assert.assertEquals("O", CTTipoDirecao.OESTE.getCodigo());
    }

}

package com.fincatto.documentofiscal.cte300.classes;

import org.junit.Assert;
import org.junit.Test;

import com.fincatto.documentofiscal.cte300.classes.CTTipoTrafego;

public class CTTipoTrafegoTest {

    @Test
    public void deveRepresentarOCodigoCorretamente() {
    	Assert.assertNull(CTTipoTrafego.valueOfCodigo(null));
    	Assert.assertEquals("0", CTTipoTrafego.PROPRIO.getCodigo());
    	Assert.assertEquals("1", CTTipoTrafego.MUTUO.getCodigo());
    	Assert.assertEquals("2", CTTipoTrafego.RODOFERROVIARIO.getCodigo());
    	Assert.assertEquals("3", CTTipoTrafego.RODOVIARIO.getCodigo());
	}

}
